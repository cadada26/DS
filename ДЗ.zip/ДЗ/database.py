import sqlite3
from typing import List, Optional
from models import Exercise, WorkoutPlan, WorkoutSession, WorkoutHistory

class Database:
    def __init__(self, db_name="workout_planner.db"):
        self.db_name = db_name
        self.init_database()

    def get_connection(self):
        return sqlite3.connect(self.db_name)

    def init_database(self):
        """Инициализация базы данных и создание таблиц"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # Таблица упражнений
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS exercises (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    description TEXT,
                    muscle_group TEXT,
                    equipment TEXT
                )
            ''')
            
            # Таблица планов тренировок
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS workout_plans (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    description TEXT,
                    created_date TEXT NOT NULL
                )
            ''')
            
            # Таблица сессий тренировок (связь планов и упражнений)
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS workout_sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    plan_id INTEGER NOT NULL,
                    exercise_id INTEGER NOT NULL,
                    sets INTEGER NOT NULL,
                    reps INTEGER NOT NULL,
                    weight REAL,
                    notes TEXT,
                    FOREIGN KEY (plan_id) REFERENCES workout_plans (id),
                    FOREIGN KEY (exercise_id) REFERENCES exercises (id)
                )
            ''')
            
            # Таблица истории тренировок
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS workout_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    plan_id INTEGER NOT NULL,
                    completed_date TEXT NOT NULL,
                    duration_minutes INTEGER,
                    notes TEXT,
                    FOREIGN KEY (plan_id) REFERENCES workout_plans (id)
                )
            ''')
            
            conn.commit()
            
            # Добавляем базовые упражнения, если таблица пуста
            self._add_default_exercises(cursor)

    def _add_default_exercises(self, cursor):
        """Добавление базовых упражнений в базу данных"""
        cursor.execute("SELECT COUNT(*) FROM exercises")
        if cursor.fetchone()[0] == 0:
            default_exercises = [
                ("Приседания со штангой", "Базовое упражнение для ног", "Ноги", "Штанга"),
                ("Жим лежа", "Упражнение для грудных мышц", "Грудь", "Штанга"),
                ("Становая тяга", "Упражнение для спины и ног", "Спина", "Штанга"),
                ("Подтягивания", "Упражнение для спины", "Спина", "Турник"),
                ("Отжимания", "Упражнение для груди и трицепсов", "Грудь", "Собственный вес"),
                ("Жим над головой", "Упражнение для плеч", "Плечи", "Штанга"),
                ("Выпады", "Упражнение для ног", "Ноги", "Собственный вес"),
                ("Планка", "Упражнение для кора", "Пресс", "Собственный вес"),
                ("Бег", "Кардио упражнение", "Кардио", "Беговая дорожка"),
                ("Велосипед", "Кардио упражнение", "Кардио", "Велотренажер")
            ]
            
            cursor.executemany(
                "INSERT INTO exercises (name, description, muscle_group, equipment) VALUES (?, ?, ?, ?)",
                default_exercises
            )

    # CRUD операции для упражнений
    def add_exercise(self, exercise: Exercise) -> int:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO exercises (name, description, muscle_group, equipment) VALUES (?, ?, ?, ?)",
                (exercise.name, exercise.description, exercise.muscle_group, exercise.equipment)
            )
            return cursor.lastrowid

    def get_all_exercises(self) -> List[Exercise]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM exercises")
            return [Exercise(*row) for row in cursor.fetchall()]

    def get_exercise_by_id(self, exercise_id: int) -> Optional[Exercise]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM exercises WHERE id = ?", (exercise_id,))
            row = cursor.fetchone()
            return Exercise(*row) if row else None

    # CRUD операции для планов тренировок
    def add_workout_plan(self, plan: WorkoutPlan) -> int:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO workout_plans (name, description, created_date) VALUES (?, ?, ?)",
                (plan.name, plan.description, plan.created_date)
            )
            return cursor.lastrowid

    def get_all_workout_plans(self) -> List[WorkoutPlan]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM workout_plans")
            return [WorkoutPlan(*row) for row in cursor.fetchall()]

    def get_workout_plan_by_id(self, plan_id: int) -> Optional[WorkoutPlan]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM workout_plans WHERE id = ?", (plan_id,))
            row = cursor.fetchone()
            return WorkoutPlan(*row) if row else None

    # CRUD операции для сессий тренировок
    def add_workout_session(self, session: WorkoutSession) -> int:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """INSERT INTO workout_sessions 
                (plan_id, exercise_id, sets, reps, weight, notes) 
                VALUES (?, ?, ?, ?, ?, ?)""",
                (session.plan_id, session.exercise_id, session.sets, session.reps, session.weight, session.notes)
            )
            return cursor.lastrowid

    def get_sessions_by_plan(self, plan_id: int) -> List[WorkoutSession]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM workout_sessions WHERE plan_id = ?", (plan_id,))
            return [WorkoutSession(*row) for row in cursor.fetchall()]

    # CRUD операции для истории тренировок
    def add_workout_history(self, history: WorkoutHistory) -> int:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """INSERT INTO workout_history 
                (plan_id, completed_date, duration_minutes, notes) 
                VALUES (?, ?, ?, ?)""",
                (history.plan_id, history.completed_date, history.duration_minutes, history.notes)
            )
            return cursor.lastrowid

    def get_workout_history(self) -> List[WorkoutHistory]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM workout_history ORDER BY completed_date DESC")
            return [WorkoutHistory(*row) for row in cursor.fetchall()]