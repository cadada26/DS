from datetime import datetime
from dataclasses import dataclass
from typing import List, Optional

@dataclass
class Exercise:
    id: Optional[int]
    name: str
    description: str
    muscle_group: str
    equipment: str

@dataclass
class WorkoutPlan:
    id: Optional[int]
    name: str
    description: str
    created_date: str

@dataclass
class WorkoutSession:
    id: Optional[int]
    plan_id: int
    exercise_id: int
    sets: int
    reps: int
    weight: float
    notes: str

@dataclass
class WorkoutHistory:
    id: Optional[int]
    plan_id: int
    completed_date: str
    duration_minutes: int
    notes: str