from datetime import datetime
from database import Database
from models import Exercise, WorkoutPlan, WorkoutSession, WorkoutHistory

class WorkoutManager:
    def __init__(self):
        self.db = Database()

    def create_exercise(self, name: str, description: str, muscle_group: str, equipment: str):
        """Создание нового упражнения"""
        exercise = Exercise(None, name, description, muscle_group, equipment)
        return self.db.add_exercise(exercise)

    def create_workout_plan(self, name: str, description: str = ""):
        """Создание нового плана тренировок"""
        plan = WorkoutPlan(None, name, description, datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        return self.db.add_workout_plan(plan)

    def add_exercise_to_plan(self, plan_id: int, exercise_id: int, sets: int, reps: int, weight: float = 0, notes: str = ""):
        """Добавление упражнения в план тренировок"""
        session = WorkoutSession(None, plan_id, exercise_id, sets, reps, weight, notes)
        return self.db.add_workout_session(session)

    def complete_workout(self, plan_id: int, duration_minutes: int, notes: str = ""):
        """Отметка завершения тренировки"""
        history = WorkoutHistory(
            None, 
            plan_id, 
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"), 
            duration_minutes, 
            notes
        )
        return self.db.add_workout_history(history)

    def get_plan_details(self, plan_id: int):
        """Получение деталей плана тренировок с упражнениями"""
        plan = self.db.get_workout_plan_by_id(plan_id)
        if not plan:
            return None

        sessions = self.db.get_sessions_by_plan(plan_id)
        plan_exercises = []
        
        for session in sessions:
            exercise = self.db.get_exercise_by_id(session.exercise_id)
            if exercise:
                plan_exercises.append({
                    'exercise': exercise,
                    'session': session
                })
        
        return {
            'plan': plan,
            'exercises': plan_exercises
        }

    def display_all_exercises(self):
        """Отображение всех доступных упражнений"""
        exercises = self.db.get_all_exercises()
        print("\n=== ДОСТУПНЫЕ УПРАЖНЕНИЯ ===")
        for i, exercise in enumerate(exercises, 1):
            print(f"{i}. {exercise.name} ({exercise.muscle_group}) - {exercise.equipment}")
            print(f"   Описание: {exercise.description}")
        return exercises

    def display_all_plans(self):
        """Отображение всех планов тренировок"""
        plans = self.db.get_all_workout_plans()
        print("\n=== ПЛАНЫ ТРЕНИРОВОК ===")
        for i, plan in enumerate(plans, 1):
            print(f"{i}. {plan.name} (Создан: {plan.created_date})")
            print(f"   Описание: {plan.description}")
            
            # Показываем упражнения в плане
            sessions = self.db.get_sessions_by_plan(plan.id)
            if sessions:
                print("   Упражнения:")
                for session in sessions:
                    exercise = self.db.get_exercise_by_id(session.exercise_id)
                    if exercise:
                        print(f"     - {exercise.name}: {session.sets}×{session.reps} ({session.weight}кг)")
        return plans

    def display_workout_history(self):
        """Отображение истории тренировок"""
        history = self.db.get_workout_history()
        print("\n=== ИСТОРИЯ ТРЕНИРОВОК ===")
        for i, record in enumerate(history, 1):
            plan = self.db.get_workout_plan_by_id(record.plan_id)
            plan_name = plan.name if plan else "Неизвестный план"
            print(f"{i}. {plan_name} - {record.completed_date}")
            print(f"   Длительность: {record.duration_minutes} мин")
            print(f"   Заметки: {record.notes}")
        return history