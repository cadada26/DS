from workout_manager import WorkoutManager

def main():
    manager = WorkoutManager()
    
    while True:
        print("\n" + "="*50)
        print("ПЛАНИРОВЩИК ТРЕНИРОВОК")
        print("="*50)
        print("1. Просмотреть все упражнения")
        print("2. Создать новое упражнение")
        print("3. Создать план тренировок")
        print("4. Добавить упражнение в план")
        print("5. Просмотреть все планы")
        print("6. Завершить тренировку")
        print("7. Просмотреть историю тренировок")
        print("8. Выйти")
        
        choice = input("\nВыберите действие: ").strip()
        
        if choice == "1":
            manager.display_all_exercises()
            
        elif choice == "2":
            print("\n--- СОЗДАНИЕ НОВОГО УПРАЖНЕНИЯ ---")
            name = input("Название упражнения: ")
            description = input("Описание: ")
            muscle_group = input("Группа мышц: ")
            equipment = input("Оборудование: ")
            
            exercise_id = manager.create_exercise(name, description, muscle_group, equipment)
            print(f"Упражнение создано с ID: {exercise_id}")
            
        elif choice == "3":
            print("\n--- СОЗДАНИЕ ПЛАНА ТРЕНИРОВОК ---")
            name = input("Название плана: ")
            description = input("Описание: ")
            
            plan_id = manager.create_workout_plan(name, description)
            print(f"План тренировок создан с ID: {plan_id}")
            
        elif choice == "4":
            print("\n--- ДОБАВЛЕНИЕ УПРАЖНЕНИЯ В ПЛАН ---")
            
            # Показываем все планы
            plans = manager.display_all_plans()
            if not plans:
                print("Сначала создайте план тренировок!")
                continue
                
            plan_choice = int(input("Выберите номер плана: ")) - 1
            if 0 <= plan_choice < len(plans):
                plan_id = plans[plan_choice].id
                
                # Показываем все упражнения
                exercises = manager.display_all_exercises()
                exercise_choice = int(input("Выберите номер упражнения: ")) - 1
                
                if 0 <= exercise_choice < len(exercises):
                    exercise_id = exercises[exercise_choice].id
                    sets = int(input("Количество подходов: "))
                    reps = int(input("Количество повторений: "))
                    weight = float(input("Вес (кг): ") or 0)
                    notes = input("Заметки: ")
                    
                    session_id = manager.add_exercise_to_plan(plan_id, exercise_id, sets, reps, weight, notes)
                    print(f"Упражнение добавлено в план!")
                else:
                    print("Неверный выбор упражнения!")
            else:
                print("Неверный выбор плана!")
                
        elif choice == "5":
            manager.display_all_plans()
            
        elif choice == "6":
            print("\n--- ЗАВЕРШЕНИЕ ТРЕНИРОВКИ ---")
            
            plans = manager.display_all_plans()
            if not plans:
                print("Сначала создайте план тренировок!")
                continue
                
            plan_choice = int(input("Выберите номер завершенного плана: ")) - 1
            if 0 <= plan_choice < len(plans):
                plan_id = plans[plan_choice].id
                duration = int(input("Длительность тренировки (минуты): "))
                notes = input("Заметки о тренировке: ")
                
                history_id = manager.complete_workout(plan_id, duration, notes)
                print("Тренировка завершена и сохранена в истории!")
            else:
                print("Неверный выбор плана!")
                
        elif choice == "7":
            manager.display_workout_history()
            
        elif choice == "8":
            print("До свидания!")
            break
            
        else:
            print("Неверный выбор! Попробуйте снова.")

if __name__ == "__main__":
    main()